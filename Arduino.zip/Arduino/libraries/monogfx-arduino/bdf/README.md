# BDF Fonts

This directory contains Glyph Bitmap Distribution Format (BDF) fonts.

## Source

The following fonts are by (usr_share)[https://opengameart.org/users/usrshare], available at [OpenGameArt](https://opengameart.org/content/a-package-of-8-bit-fonts-for-grafx2-and-linux) and licenced as Public Domain:

- ArtosSans-8.bdf
- SaikyoSansBold-8.bdf
- TorusSansBold-8.bdf
- VictoriaBold-8.bdf
- VictoriaMedium-8.bdf

The following are Genera fonts, available at [Github](https://github.com/jethrovt/genera-fonts):

- Helvetica-\*.bdf
- HelveticaBold-\*.bdf
