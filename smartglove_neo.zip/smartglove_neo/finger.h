/*
 * Copyright (C) 2020 by Stefan Rothe
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, eithe4r version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef FINGER_H
#define FINGER_H

#include <Arduino.h>
#include "SparkFun_Displacement_Sensor_Arduino_Library.h"

class Adafruit_NeoPixel;

// ----------------------------------------------------------------------------
// class Finger
// ----------------------------------------------------------------------------

class Finger {
public:
    Finger();
    void init(uint8_t flexSensorAddress, uint8_t neoPixelPin);
    bool available();
    float readFlex();
private:
    ADS _flexSensor;
    Adafruit_NeoPixel* _neopixel;
    void fill(uint32_t color);
};

#endif
